// JavaScript source code
// JavaScript source code
let x = 100;
let y = 100;
var myXs = []; // create an array for the x coordinate
var myYs = []; // create an array for the y coordinate
var myDiameters = []; // create array for the diameter of circles
var speed = 2;
var a = 100;
var b = 100;
var clickx = 0;
var clicky = 0;

function setup() {
    createCanvas(400, 400);
    fill(255, 0, 0);
    for (var i = 0; i < 5; i++) {
        // get all the random numbers to create a circle
        myXs[i] = getRandomX(400);
        myYs[i] = getRandomY(400);
        myDiameters[i] = getRandomDiameter(100);
    }
}

function draw() {
    background(220);

    move();
    createPlayer();
    controlCircle();
    createCircle();
    exit();
    youWin();

    for (var i = 0; i < myXs.length; i++) {
        fill(Math.floor(Math.random() * 256), Math.floor(Math.random() * 256), Math.floor(Math.random() * 256));
        circle(myXs[i], myYs[i], myDiameters[i]);
    }



}

function mouseClicked() {
    fill(190, 90, 111);
    circle(clickx, clicky, 20);
    clickx = mouseX;
    clicky = mouseY;
}

function controlCircle() {
    if (keyIsDown(LEFT_ARROW)) {
        x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
        x += 5;
    }

    if (keyIsDown(UP_ARROW)) {
        y -= 5;
    }

    if (keyIsDown(DOWN_ARROW)) {
        y += 5;
    }





}

function createPlayer() {
    fill(255, 0, 0);
    ellipse(x, y, 50, 50);
    if (x >= 400) { x = 0; }
    else if (y >= 400) { y = 0; }

}

function move() {
    for (var i = 0; i < myXs.length; i++) {
        myXs[i] += speed;

        if (myXs[i] > width) { myXs[i] = 0 }

    }
}

function createCircle() {
    fill(190, 90, 111);
    circle(clickx, clicky, 20);
}

function exit() {
    fill(0);
    rect(300, 0, 80, 50);
    fill(255);
    textSize(30);
    text("Exit", 300, 30)
}

function youWin() {
    if (x > 300 && y <= 50) {
        text("You Won!", 150, 50);
    }

}
function getRandomX(x) {
    return Math.floor(Math.random() * x) + 10;
}

function getRandomY(y) {
    return Math.floor(Math.random() * y) + 10;
}

function getRandomDiameter(diameter) {
    return Math.floor(Math.random() * diameter) + 10
}

